package com.BankTrans;

import java.sql.*;


public class Bank1 {

    public static void main(String[] args) {
        try {
            // Assume you have a database connection
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "root123");

            // Retrieve data from the banktrans table
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM banktrans");

            // Process each row
            while (resultSet.next()) {
                int transId = resultSet.getInt("transid");
                int acctNo = resultSet.getInt("acctno");
                double oldBal = resultSet.getDouble("oldbal");
                String transType = resultSet.getString("transtype");
                double transAmt = resultSet.getDouble("transamt");
                double newbal = resultSet.getDouble("newbal");
                String transStatus = resultSet.getString("transStat");
                
                System.out.println(transId + " " + acctNo + " " + oldBal + " " + transType + " " + transAmt + " " + newbal + " " + transStatus);
                

                // Perform the transaction and update new balance
                double newBal = (transType.equals("D")) ? oldBal - transAmt : oldBal + transAmt;
                String transStat = (newBal >= 0) ? "valid" : "invalid";

                // Update new balance and transaction status in the banktrans table
                PreparedStatement updateStatement = connection.prepareStatement("UPDATE banktrans SET newbal=?, transStat=? WHERE transid=?");
                updateStatement.setDouble(1, newBal);
                updateStatement.setString(2, transStat);
                updateStatement.setInt(3, transId);
                updateStatement.executeUpdate();

                // Log the information into validtrans or invalidtrans table
                //String logTable = (transStat.equals("valid")) ? "ValidTrans" : "InvalidTrans";
                
                //String validity =  transStat.equals("valid") ? "logStatement" : "invalid";

                PreparedStatement Statement = connection.prepareStatement("INSERT INTO ValidTrans VALUES ( ?, ?, ?, ?)");
                PreparedStatement Statement1 = connection.prepareStatement("INSERT INTO InValidTrans VALUES ( ?, ?, ?, ?)");
               if(transStat.equals("valid")) {
                	Statement.setInt(1, transId);
                	Statement.setString(2, transType);
                	Statement.setDouble(3, transAmt);
                	Statement.setString(4, transStat);
                	Statement.executeUpdate();
            }
               else {
            	Statement1.setInt(1, transId);
               	Statement1.setString(2, transType);
               	Statement1.setDouble(3, transAmt);
               	Statement1.setString(4, transStat);
               	Statement1.executeUpdate();
               }
            }
            // Close resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
