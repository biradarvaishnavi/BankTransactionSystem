/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module BankTrans {
	requires java.sql;
}